const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
app.use(express.json());
app.use(cors());

// Database Connect
mongoose.connect("mongodb://127.0.0.1:27017/task_manager")
  .then(() => console.log("MongoDB Connected Successfully!")) 
  .catch((err) => console.log("Connection Error:", err));

// Route - Aa line browser ma dekhase
app.get("/", (req, res) => {
  res.send("Day 1 Task Completed: Server & Database Connected!");
});

app.listen(5000, () => {
  console.log("Server started on port 5000");
});